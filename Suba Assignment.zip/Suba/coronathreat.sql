-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: Apr 16, 2020 at 09:21 AM
-- Server version: 8.0.18
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `patients`
--

-- --------------------------------------------------------

--
-- Table structure for table `coronathreat`
--

DROP TABLE IF EXISTS `coronathreat`;
CREATE TABLE IF NOT EXISTS `coronathreat` (
  `STATE` varchar(50) NOT NULL,
  `CITY` varchar(50) NOT NULL,
  `MALE` int(11) NOT NULL,
  `FEMALE` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `coronathreat`
--

INSERT INTO `coronathreat` (`STATE`, `CITY`, `MALE`, `FEMALE`) VALUES
('Tamilnadu', 'Chennai', 60, 30),
('Tamilnadu', 'Coimbatore', 25, 10),
('AndhraPradesh', 'Chitoor', 15, 20),
('AndhraPradesh', 'Vijayawada', 45, 31),
('Kerala', 'Cochin', 75, 45),
('Kerala', 'Wayanad', 15, 15);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
