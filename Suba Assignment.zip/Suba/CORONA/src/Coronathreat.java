import java.sql.*;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.Map;
import java.util.Map.Entry;


public class Coronathreat {
	public static void main(String[] args) {
		
		Connection myconn=null;
		Statement mystmt =null;
		ResultSet myrs= null;
		int tnsum_male= 0; int tnsum_female= 0;
		int apsum_male= 0; int apsum_female= 0;
		int klsum_male= 0; int klsum_female= 0;
		
	   Map<String, Integer>map1 = new TreeMap<String, Integer>();
       Map<String, Integer>map2 = new TreeMap<String, Integer>();
       Map<String, String>map3 = new TreeMap<String, String>();
       
      try {
    	  myconn= DriverManager.getConnection("jdbc:mysql://localhost:3308/patients", "root",null);
    	  mystmt=myconn.createStatement();
    	  myrs=mystmt.executeQuery("select * from coronathreat");
    	  while (myrs.next())
    	  {
    		  if(myrs.getString("STATE").equals("Tamilnadu"))
    		  {map3.put(myrs.getString("CITY"),"Tamilnadu");
    		  }
    		  else if (myrs.getString("STATE").equals("AndhraPradesh"))
    		  {map3.put(myrs.getString("CITY"),"AndhraPradesh");
    		  }
    		  else
    		  {map3.put(myrs.getString("CITY"),"Kerala");
    		  }
    		  map1.put(myrs.getString("CITY"),Integer.parseInt(myrs.getString("MALE")));
    		  map2.put(myrs.getString("CITY"), Integer.parseInt(myrs.getString("FEMALE")));
    	  }
    	 }
      catch(Exception e)
      {System.out.println("Database not found");
      }
	
    Iterator iterator1 = map1.entrySet().iterator();
     while (iterator1.hasNext()) {
    	 Map.Entry maleentry=(Map.Entry)iterator1.next();
    	 if ((map3.get(maleentry.getKey())).equals("Tamilnadu"))
    	 {  tnsum_male = tnsum_male + (int)maleentry.getValue();
    	 }
    	 else if ((map3.get(maleentry.getKey())).equals("AndhraPradesh"))
    	 { apsum_male = apsum_male + (int)maleentry.getValue();
    	 }
    	 else
    	 {  klsum_male = klsum_male + (int)maleentry.getValue();
    	 }
    	 }
     
     Iterator iterator2 = map2.entrySet().iterator();
     while (iterator2.hasNext()) {
    	 Map.Entry femaleentry=(Map.Entry)iterator2.next();
    	 if ((map3.get(femaleentry.getKey())).equals("Tamilnadu"))
    	 {  tnsum_female = tnsum_female + (int)femaleentry.getValue();
    	 }
    	 else if ((map3.get(femaleentry.getKey())).equals("AndhraPradesh"))
    	 { apsum_female = apsum_female + (int)femaleentry.getValue();
    	 }
    	 else
    	 {  klsum_female = klsum_female + (int)femaleentry.getValue();
    	 }
    	 }
     
     System.out.println("TN total no.of male patients" + ":" + tnsum_male + " " +"TN total no. of female patients"+ ":" + tnsum_female);
      int tntotal = tnsum_male + tnsum_female;
     System.out.println("The total no.of patients in Tn: " + tntotal);
     
     System.out.println("AP total no. of male patients" + ":" + apsum_male + " " + "AP total no.of female pat" + ":" + apsum_female );
     int aptotal = apsum_male + apsum_female;
     System.out.println("The total count in Ap:" + aptotal);
     
     System.out.println("KL total no.of male patients" + ":" + klsum_male + " " + "KL total no.of female patients" + ":" + klsum_female);
     int kltotal = klsum_male + klsum_female;
     System.out.println("The total count in Kl:" + kltotal);
     
     int totalmale = tnsum_male + apsum_male + + klsum_male ;
     int totalfemale = tnsum_female + apsum_female + klsum_female;
     int grandtotal = totalmale + totalfemale;
     System.out.println("The total no. of patients in all three states is " + ":" + grandtotal);
       }
}